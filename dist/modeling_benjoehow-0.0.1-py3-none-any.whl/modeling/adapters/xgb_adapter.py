import xgboost as xgb


class xgb_adapter:
    
    def __init__(self):
        pass
    
    def get_jobs(self, params):
        pass
    
    def prep_data(self, df, features, label):
        pass
        
    def train(self, params, data):
        
        num_boost_round = max(params["num_boost_round"])
        params.pop("num_boost_round")
        
        model = xgboost.train(params = params,
                              dtrain = data,
                              num_boost_round = num_boost_round)
        
    def predict(self, model, data):
        